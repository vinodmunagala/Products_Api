# This file should ensure the existence of records required to run the application in every environment (production,
# development, test). The code here should be idempotent so that it can be executed at any point in every environment.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Example:
#
#   ["Action", "Comedy", "Drama", "Horror"].each do |genre_name|
#     MovieGenre.find_or_create_by!(name: genre_name)
#   end

Product.create!([
  { name: 'Product A', price: 5000.00, status: 'approved_queue', is_deleted: 0, approved_date: nil, request_date: Time.now },
  { name: 'Product B', price: 8020.49, status: 'approved_queue', is_deleted: 0, approved_date: nil, request_date: Time.now  },
  { name: 'Product C', price: 15.75, status: 'inprogress', is_deleted: 0, approved_date: nil, request_date: nil  },
  { name: 'Product D', price: 6500.99, status: 'approved', is_deleted: 0, approved_date: 20-02-2024, request_date: nil  },
  { name: 'Product E', price: 20.49, status: 'inprogress', is_deleted: 0, approved_date: nil, request_date: nil  },
  { name: 'Product F', price: 5015.75, status: 'approved', is_deleted: 0, approved_date: 22-02-2024, request_date: Time.now   },
  { name: 'Product G', price: 10.99, status: 'approved_queue', is_deleted: 1, approved_date: nil, request_date: Time.now  },
  { name: 'Product H', price: 20.49, status: 'rejected', is_deleted: 0, approved_date: nil, request_date: Time.now  },
  { name: 'Product I', price: 15.75, status: 'inprogress', is_deleted: 0, approved_date: nil, request_date: Time.now   },
  { name: 'Product J', price: 15.75, status: 'deleted', is_deleted: 1, approved_date: nil, request_date: Time.now   }
])
