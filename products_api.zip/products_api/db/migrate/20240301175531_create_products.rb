class CreateProducts < ActiveRecord::Migration[7.1]
  def change
    create_table :products do |t|
      t.string :name, null: false
      t.decimal :price, null: false
      t.integer :status, null: false, default: 0
      t.date :request_date
      t.datetime :approved_date
      t.boolean :is_deleted

      t.timestamps
    end
  end
end
