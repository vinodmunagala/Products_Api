class Api::V1::ProductsController < ApplicationController
  before_action :set_product, only: %I[update destroy approve reject]

  def index
    @products = Product.approved.order(created_at: :desc)
    render json: @products
  end

  def search
    @products = Product.search(params)
    render json: @products
  end

  def create
    @product = Product.new(product_params)
    if @product.save
      render json: @product, status: :created
    else
      render json: @product.errors, status: :unprocessable_entity
    end
  end

  def update
    if @product.update(product_params)
      render json: @product
    else
      render json: @product.errors, status: :unprocessable_entity
    end
  end

  def destroy
    product = Product.find(params[:id])
    product.update(status: 'approve_queue', request_date: Time.now, is_deleted: 1)
    render json: {message: "Product deleted, waiting for approval."}
  end

  def approval_queue
    @products = Product.approved_queue.order(request_date: :asc)
    render json: @products
  end

  def approve
    @product.update(status: 'approved', request_date: nil)
    render json: {message: "Product Approved."}
  end

  def reject
    @product.update(status: 'rejected', request_date: nil)
    render json: {message: "Product Rejectd."}
  end

  private

  def set_product
    @product = Product.find(params[:id])
  end

  def product_params
    params.require(:product).permit(:name, :price, :status)
  end
end