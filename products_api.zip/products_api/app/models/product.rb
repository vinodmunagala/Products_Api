class Product < ApplicationRecord
  enum status: %i[inprogress approved approved_queue rejected deleted]
	validates :name, :price, :status, presence: true
  validates :price, numericality: { less_than_or_equal_to: 10000 }

  after_create :set_approved_queue_status, if: ->(product) { product.price >= 5000 }
  after_save :check_price_change, if: ->(product) { product.price_changed? }

  scope :by_name, ->(name) { where("name LIKE ?", "%#{name}%") if name.present? }
  scope :by_min_price, ->(min_price) { where("price >= ?", min_price) if min_price.present? }
  scope :by_max_price, ->(max_price) { where("price <= ?", max_price) if max_price.present? }
  scope :by_min_posted_date, ->(min_posted_date) { where("created_at >= ?", min_posted_date) if min_posted_date.present? }
  scope :by_max_posted_date, ->(max_posted_date) { where("created_at <= ?", max_posted_date) if max_posted_date.present? }

  def self.search(params)
    products = all

    products = products.by_product_name(params[:productName]) if params[:productName].present?
    products = products.by_min_price(params[:minPrice]) if params[:minPrice].present?
    products = products.by_max_price(params[:maxPrice]) if params[:maxPrice].present?
    products = products.by_min_posted_date(params[:minPostedDate]) if params[:minPostedDate].present?
    products = products.by_max_posted_date(params[:maxPostedDate]) if params[:maxPostedDate].present?

    products
  end

  private

  def set_approved_queue_status
    self.update(status: 'approved_queue', request_date: Time.now)
  end

  def check_price_change
    previous_price = price_was || 0
    if ((price - previous_price) / previous_price.to_f) > 0.5
      self.update(status: 'approved_queue', request_date: Time.now)
    end
  end
end
